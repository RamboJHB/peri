=====================
Compte Rendu PERI TP4
=====================
1. Communication par FIFO
------------------------------------------------------------
writer.py:

**Dans quel répertoire est créee la fifo ?**

| '/tmp/myfifo'

**Quelle différence mkfifo et open ?**

| *mkfifo* c'est la création d'une fifo, et *open* c'est pour ouvrir la fifo après la création.

**Pourquoi tester que la fifo existe ?**

| Parce que parfois la fifo n'est pas bien contruit.(Par exemple s'il n'y pas place sur disque.) 

**A quoi sert flush ?**

| le *flush* permet d'écrire les données dans le buffer du programme à le fichier actuel et vider le buffer.

**Pourquoi ne ferme-t-on pas la fifo ?**

| Parce que si on ferme la fifo, on ne peut plus utiliser la fifo, donc normalement on utilise flush pour écrire des données  


reader.py:

**Que fait readline ?**

| *readline* c'est pour lire un fichier dans une variable de type *string*, et on lit une ligne chaque fois.


**Lorsqu'on lance un écrivain (en C ou en Pyhton) rien ne se passe tant que vous n'avez pas lancé un lecteur.Expliquez le phénomème.**

| Si on exécute un écrivain, les données sont stockées dans le buffer, mais on ne peut pas les afficher, donc il faut lancer un lecteur pour savoir le contenu d'écriture. 


2. Création d'un serveur fake
-------------------------------------------------
Dans le fake.c,on ajoute le code suivant:

| if (FD_ISSET(STDIN_FILENO, &rfds)) {                   
| 		//read stdin to buf
| 		if ((nbchar = read(STDIN_FILENO, buf, sizeof(buf))) == 0) break;
| 	        printf("---entered---\n");
| 		//write  buf to f2s
|                 if ((nbchar = write(f2s,buf, sizeof(buf))) == 0) break;
| 	        printf("---f2s---\n");
|               fprintf(stderr,"%s", serverRequest);
| 		memset (buf,0,sizeof(buf));
| 

Dans le ficher serveur.py on ajoute *f2s.flush()* pour renouveler.


3. Création d'un serveur web 
----------------------------------



**----Veuillez regarder le code pour les questions ci-dessus.**

